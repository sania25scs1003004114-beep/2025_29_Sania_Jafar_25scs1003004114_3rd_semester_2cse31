# Task 04 - Sudoku Solver

A 9×9 Sudoku solver implemented using the **backtracking algorithm**.

### How it works

1. Find an empty cell.
2. Try numbers from 1 to 9.
3. Check whether the number is valid in the row, column, and 3×3 box.
4. If valid, place the number.
5. Recursively continue.
6. If the choice leads to a dead end, undo it and try another number.

`0` represents an empty cell.

### Concepts Used
- Recursion
- Backtracking
- 2D lists
- Functions
- Constraint checking
