# Task 03 - Simple Contact Management System

A menu-driven contact management application that stores contact information persistently in a JSON file.

### Features
- Add a contact
- View all contacts
- Search contacts by name or phone
- Delete a contact
- Persistent storage using `contacts.json`

### Contact Information
Each contact contains:
- Name
- Phone number
- Email address

### Concepts Used
- Lists and dictionaries
- Functions
- CRUD operations
- JSON
- File handling
- Input validation
