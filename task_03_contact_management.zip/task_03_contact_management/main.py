"""
Task 03 - Simple Contact Management System

A menu-driven contact manager with persistent JSON storage.
Users can add, view, search, and delete contacts.
"""

import json
from pathlib import Path

DATA_FILE = Path(__file__).parent / "contacts.json"


def load_contacts():
    if not DATA_FILE.exists():
        return []

    try:
        with DATA_FILE.open("r", encoding="utf-8") as file:
            return json.load(file)
    except (json.JSONDecodeError, OSError):
        return []


def save_contacts(contacts):
    with DATA_FILE.open("w", encoding="utf-8") as file:
        json.dump(contacts, file, indent=4)


def add_contact(contacts):
    print("\n--- Add Contact ---")
    name = input("Name: ").strip()
    phone = input("Phone number: ").strip()
    email = input("Email address: ").strip()

    if not name or not phone or not email:
        print("All fields are required.")
        return

    contacts.append({
        "name": name,
        "phone": phone,
        "email": email
    })
    save_contacts(contacts)
    print("Contact added successfully.")


def view_contacts(contacts):
    print("\n--- Contact List ---")

    if not contacts:
        print("No contacts found.")
        return

    for index, contact in enumerate(contacts, start=1):
        print(f"\nContact {index}")
        print(f"Name : {contact['name']}")
        print(f"Phone: {contact['phone']}")
        print(f"Email: {contact['email']}")


def search_contacts(contacts):
    keyword = input("\nEnter name or phone to search: ").strip().lower()

    matches = [
        contact for contact in contacts
        if keyword in contact["name"].lower()
        or keyword in contact["phone"].lower()
    ]

    if not matches:
        print("No matching contacts found.")
        return

    print("\n--- Search Results ---")
    for contact in matches:
        print(f"Name : {contact['name']}")
        print(f"Phone: {contact['phone']}")
        print(f"Email: {contact['email']}")
        print("-" * 25)


def delete_contact(contacts):
    if not contacts:
        print("\nNo contacts to delete.")
        return

    view_contacts(contacts)

    try:
        number = int(input("\nEnter contact number to delete: "))
        if not 1 <= number <= len(contacts):
            print("Invalid contact number.")
            return
    except ValueError:
        print("Please enter a valid number.")
        return

    removed = contacts.pop(number - 1)
    save_contacts(contacts)
    print(f"Deleted contact: {removed['name']}")


def main():
    contacts = load_contacts()

    while True:
        print("\n" + "=" * 45)
        print("       CONTACT MANAGEMENT SYSTEM")
        print("=" * 45)
        print("1. Add Contact")
        print("2. View Contacts")
        print("3. Search Contact")
        print("4. Delete Contact")
        print("5. Exit")

        choice = input("Enter your choice (1-5): ").strip()

        if choice == "1":
            add_contact(contacts)
        elif choice == "2":
            view_contacts(contacts)
        elif choice == "3":
            search_contacts(contacts)
        elif choice == "4":
            delete_contact(contacts)
        elif choice == "5":
            print("Thank you for using the Contact Management System.")
            break
        else:
            print("Invalid choice. Please select 1-5.")


if __name__ == "__main__":
    main()
