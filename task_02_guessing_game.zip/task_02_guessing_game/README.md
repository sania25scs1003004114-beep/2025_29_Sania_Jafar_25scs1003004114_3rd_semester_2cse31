# Task 02 - Guessing Game

A simple number guessing game in which the computer chooses a random number between 1 and 100.

The program:
1. Generates a random number.
2. Takes guesses from the user.
3. Tells the user whether the guess is too high or too low.
4. Continues until the correct number is guessed.
5. Displays the total number of attempts.

### Concepts Used
- `random` module
- `while` loop
- `if/elif/else`
- Input validation
- Counters
