# Task 05 - Web Scraping

A Python web scraper that extracts book information from **Books to Scrape**, a website designed for practicing web scraping.

### Data Collected
- Book name
- Price
- Rating

The information is stored in `products.csv`.

### Installation

From the repository root:

```bash
pip install -r requirements.txt
```

### Run

```bash
python task_05_web_scraping/main.py
```

### Technologies
- Python
- Requests
- BeautifulSoup
- CSV

### Important

Use web scraping only where it is permitted by the website's terms and applicable rules. This project uses Books to Scrape because it is specifically intended as a scraping practice site.
