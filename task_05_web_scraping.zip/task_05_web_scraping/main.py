"""
Task 05 - Web Scraping

Scrapes book information from Books to Scrape:
- Book title
- Price
- Rating

The collected data is saved to products.csv.
"""

import csv
import time
from pathlib import Path

import requests
from bs4 import BeautifulSoup

BASE_URL = "https://books.toscrape.com/"
OUTPUT_FILE = Path(__file__).parent / "products.csv"

RATING_MAP = {
    "One": 1,
    "Two": 2,
    "Three": 3,
    "Four": 4,
    "Five": 5
}


def scrape_books():
    books = []
    url = BASE_URL

    headers = {
        "User-Agent": "Mozilla/5.0 (compatible; EducationalScraper/1.0)"
    }

    while url:
        print(f"Scraping: {url}")

        response = requests.get(url, headers=headers, timeout=15)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")

        for item in soup.select("article.product_pod"):
            title_tag = item.select_one("h3 a")
            price_tag = item.select_one(".price_color")
            rating_tag = item.select_one("p.star-rating")

            if not (title_tag and price_tag and rating_tag):
                continue

            rating_class = next(
                (class_name for class_name in rating_tag.get("class", [])
                 if class_name in RATING_MAP),
                None
            )

            books.append({
                "title": title_tag.get("title", title_tag.get_text(strip=True)),
                "price": price_tag.get_text(strip=True),
                "rating": RATING_MAP.get(rating_class, "Unknown")
            })

        next_button = soup.select_one("li.next a")
        url = BASE_URL + next_button["href"] if next_button else None

        # Small delay between pages.
        if url:
            time.sleep(0.5)

    return books


def save_to_csv(books):
    with OUTPUT_FILE.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=["title", "price", "rating"]
        )
        writer.writeheader()
        writer.writerows(books)


def main():
    print("=" * 50)
    print("             BOOK WEB SCRAPER")
    print("=" * 50)

    try:
        books = scrape_books()
        save_to_csv(books)

        print(f"\nScraping completed successfully.")
        print(f"Books collected: {len(books)}")
        print(f"Data saved to: {OUTPUT_FILE}")

    except requests.RequestException as error:
        print(f"\nNetwork error: {error}")
        print("Please check your internet connection and try again.")
    except OSError as error:
        print(f"\nFile error: {error}")


if __name__ == "__main__":
    main()
