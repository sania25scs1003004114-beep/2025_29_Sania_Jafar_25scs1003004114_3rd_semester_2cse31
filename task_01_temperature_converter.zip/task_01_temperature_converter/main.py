"""
Task 01 - Temperature Conversion Program

Converts a temperature between Celsius, Fahrenheit, and Kelvin.
"""

def celsius_to_fahrenheit(celsius):
    return (celsius * 9 / 5) + 32


def celsius_to_kelvin(celsius):
    return celsius + 273.15


def fahrenheit_to_celsius(fahrenheit):
    return (fahrenheit - 32) * 5 / 9


def fahrenheit_to_kelvin(fahrenheit):
    return (fahrenheit - 32) * 5 / 9 + 273.15


def kelvin_to_celsius(kelvin):
    return kelvin - 273.15


def kelvin_to_fahrenheit(kelvin):
    return (kelvin - 273.15) * 9 / 5 + 32


def get_temperature():
    while True:
        try:
            return float(input("Enter temperature value: "))
        except ValueError:
            print("Please enter a valid number.")


def main():
    print("=" * 45)
    print("       TEMPERATURE CONVERSION PROGRAM")
    print("=" * 45)
    print("1. Celsius")
    print("2. Fahrenheit")
    print("3. Kelvin")

    while True:
        choice = input("Choose the original unit (1-3): ").strip()
        if choice in {"1", "2", "3"}:
            break
        print("Invalid choice. Please enter 1, 2, or 3.")

    temperature = get_temperature()

    if choice == "1":
        fahrenheit = celsius_to_fahrenheit(temperature)
        kelvin = celsius_to_kelvin(temperature)
        print(f"\n{temperature:.2f} °C = {fahrenheit:.2f} °F")
        print(f"{temperature:.2f} °C = {kelvin:.2f} K")

    elif choice == "2":
        celsius = fahrenheit_to_celsius(temperature)
        kelvin = fahrenheit_to_kelvin(temperature)
        print(f"\n{temperature:.2f} °F = {celsius:.2f} °C")
        print(f"{temperature:.2f} °F = {kelvin:.2f} K")

    else:
        if temperature < 0:
            print("\nKelvin temperature cannot be negative.")
            return

        celsius = kelvin_to_celsius(temperature)
        fahrenheit = kelvin_to_fahrenheit(temperature)
        print(f"\n{temperature:.2f} K = {celsius:.2f} °C")
        print(f"{temperature:.2f} K = {fahrenheit:.2f} °F")


if __name__ == "__main__":
    main()
