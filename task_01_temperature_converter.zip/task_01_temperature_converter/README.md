# Task 01 - Temperature Conversion Program

A command-line program that converts a temperature from its original unit to the other two units.

### Supported Units
- Celsius
- Fahrenheit
- Kelvin

### Example

Input:

```text
Choose the original unit (1-3): 1
Enter temperature value: 25
```

Output:

```text
25.00 °C = 77.00 °F
25.00 °C = 298.15 K
```

### Concepts Used
- Functions
- User input
- Conditional statements
- Error handling
- Mathematical formulas
