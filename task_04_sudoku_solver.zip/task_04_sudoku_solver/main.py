"""
Task 04 - Sudoku Solver

Solves a standard 9x9 Sudoku puzzle using recursive backtracking.
Use 0 for empty cells.
"""

GRID_SIZE = 9
SUBGRID_SIZE = 3


def print_grid(grid):
    for row in range(GRID_SIZE):
        if row in (3, 6):
            print("-" * 21)

        for col in range(GRID_SIZE):
            if col in (3, 6):
                print("|", end=" ")

            value = grid[row][col]
            print(value if value != 0 else ".", end=" ")

        print()


def is_valid(grid, row, col, number):
    # Check row
    if number in grid[row]:
        return False

    # Check column
    for current_row in range(GRID_SIZE):
        if grid[current_row][col] == number:
            return False

    # Check 3x3 subgrid
    start_row = row - row % SUBGRID_SIZE
    start_col = col - col % SUBGRID_SIZE

    for r in range(start_row, start_row + SUBGRID_SIZE):
        for c in range(start_col, start_col + SUBGRID_SIZE):
            if grid[r][c] == number:
                return False

    return True


def find_empty_cell(grid):
    for row in range(GRID_SIZE):
        for col in range(GRID_SIZE):
            if grid[row][col] == 0:
                return row, col
    return None


def solve_sudoku(grid):
    empty_cell = find_empty_cell(grid)

    if empty_cell is None:
        return True

    row, col = empty_cell

    for number in range(1, 10):
        if is_valid(grid, row, col, number):
            grid[row][col] = number

            if solve_sudoku(grid):
                return True

            # Backtrack
            grid[row][col] = 0

    return False


def main():
    # 0 represents an empty cell.
    grid = [
        [5, 3, 0, 0, 7, 0, 0, 0, 0],
        [6, 0, 0, 1, 9, 5, 0, 0, 0],
        [0, 9, 8, 0, 0, 0, 0, 6, 0],
        [8, 0, 0, 0, 6, 0, 0, 0, 3],
        [4, 0, 0, 8, 0, 3, 0, 0, 1],
        [7, 0, 0, 0, 2, 0, 0, 0, 6],
        [0, 6, 0, 0, 0, 0, 2, 8, 0],
        [0, 0, 0, 4, 1, 9, 0, 0, 5],
        [0, 0, 0, 0, 8, 0, 0, 7, 9]
    ]

    print("=" * 35)
    print("          SUDOKU SOLVER")
    print("=" * 35)

    print("\nOriginal Puzzle:")
    print_grid(grid)

    if solve_sudoku(grid):
        print("\nSolved Puzzle:")
        print_grid(grid)
    else:
        print("\nNo solution exists for this puzzle.")


if __name__ == "__main__":
    main()
