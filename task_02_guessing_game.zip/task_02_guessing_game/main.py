"""
Task 02 - Guessing Game

The computer generates a random number from 1 to 100.
The player keeps guessing until the correct number is found.
"""

import random


def main():
    secret_number = random.randint(1, 100)
    attempts = 0

    print("=" * 45)
    print("          NUMBER GUESSING GAME")
    print("=" * 45)
    print("I have selected a number between 1 and 100.")

    while True:
        try:
            guess = int(input("Enter your guess: "))
        except ValueError:
            print("Please enter a whole number.")
            continue

        if not 1 <= guess <= 100:
            print("Please enter a number between 1 and 100.")
            continue

        attempts += 1

        if guess < secret_number:
            print("Too low! Try again.")
        elif guess > secret_number:
            print("Too high! Try again.")
        else:
            print(f"\nCorrect! The number was {secret_number}.")
            print(f"You won in {attempts} attempt(s).")
            break


if __name__ == "__main__":
    main()
